interface Window {
  $message: any
}

type TimeProp= NodeJS.Timeout