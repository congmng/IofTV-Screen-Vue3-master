/*
 * @Author: daidai
 * @Date: 2021-12-23 11:18:37

 * @LastEditTime: 2024-03-28 16:07:20
 * @FilePath: \web-pc-svn\src\api\modules\index.js
 */

import {GETNOBASE} from "./api";
export * from "./modules/index"
export {GETNOBASE}
