export enum StorageEnum {
  // token 
  GB_TOKEN_STORE = 'GB_TOKEN_STORE',

  // 语言
  YH_LANG_STORE = 'YH_LANG',
  //皮肤
  YH_THEME_STORE = 'YH_THEME',
}
