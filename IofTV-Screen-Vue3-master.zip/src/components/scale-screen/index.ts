import ScaleScreen from './scale-screen.vue'

export default ScaleScreen