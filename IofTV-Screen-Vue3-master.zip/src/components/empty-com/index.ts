import EmptyCom from "./empty-com.vue"
export default EmptyCom