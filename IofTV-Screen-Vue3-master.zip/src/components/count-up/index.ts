import CountUp from "./count-up.vue"
export default CountUp

