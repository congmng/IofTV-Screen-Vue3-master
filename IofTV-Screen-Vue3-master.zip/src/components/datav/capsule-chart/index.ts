import CapsuleChart from "./capsule-chart.vue"
export * from "./index.d"
export default CapsuleChart