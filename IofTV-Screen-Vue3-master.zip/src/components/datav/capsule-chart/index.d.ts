export interface DefaultConfigType {
  
    colors: Array<String>;
      unit:string,
      showValue:Boolean
  }