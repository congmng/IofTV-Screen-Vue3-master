import BorderBox13 from "./border-box-13.vue"

export default BorderBox13