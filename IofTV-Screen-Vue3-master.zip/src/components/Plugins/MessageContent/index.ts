import MessageContent from './index.vue';

export default MessageContent ;
