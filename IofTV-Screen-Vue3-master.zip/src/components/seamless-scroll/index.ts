import SeamlessScroll from "./seamless-scroll.vue"
export default SeamlessScroll